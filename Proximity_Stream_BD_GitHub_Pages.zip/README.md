# Proximity Stream BD — GitHub Pages

Static HTML/CSS/JavaScript website. No PHP, MySQL, or admin panel required.

## Edit your details
Open `assets/config.js` and replace:
- `telegramUrl` with your Telegram channel/group link.
- `android.url` with your direct APK download link.
- `windows.url` with your Windows installer download link.
- Update version, file size, and the `updates` list as needed.

Use direct file URLs. GitHub Releases asset links can be used for APK/EXE downloads.

## Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`, `README.md`, and the entire `assets` folder to the repository root.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**.
5. Choose branch **main** and folder **/(root)**, then Save.
6. Wait for the published website URL to appear in the Pages section.

To change links or update logs later, edit `assets/config.js` on GitHub.